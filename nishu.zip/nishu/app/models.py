# Create your models here.
from django.db import models
from django.utils import timezone


class payment_stats(models.Model):
    status = models.CharField(max_length=10)
    firstname = models.CharField(max_length=10)
    amount = models.FloatField(max_length=10)
    txnid = models.CharField(max_length=20)
    productinfo = models.CharField(max_length=20)


class promotion(models.Model):
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=40)
    phone = models.IntegerField()
    start_date = models.DateField(null=True)
    duration = models.CharField(max_length=10)
    end_date = models.DateField(null=True)


class datelist(models.Model):
    product = models.CharField(max_length=30)
    qty = models.IntegerField(default=0)
    price = models.FloatField(default=0)
    date = models.DateField(default=timezone.now)


class enquiry1(models.Model):
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=40)
    phone = models.IntegerField()
    date = models.DateField(default=timezone.now)
    plans = models.CharField(max_length=40)


class mail1(models.Model):
    email = models.EmailField()
    password = models.CharField(max_length=30)


class organization(models.Model):
    organizationname = models.CharField(max_length=100)
    organizationemail = models.EmailField()
    organizationpassword = models.CharField(max_length=30)


class SalesReport(models.Model):
    month = models.IntegerField()
    sales = models.FloatField()
    item = models.CharField(max_length=25)
    actual_price = models.FloatField()


class get(models.Model):
    email = models.CharField(max_length=40)


class get1(models.Model):
    email = models.EmailField()


class register(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    password = models.CharField(max_length=50)


class enroll(models.Model):
    premium = models.IntegerField()
    buisness = models.IntegerField()


class expendtitureDetails(models.Model):
    item = models.CharField(max_length=10, blank=False, null=False)
    quantity = models.IntegerField(blank=False, null=False)
    price = models.FloatField(blank=False, null=False, default=0)
    Date = models.DateField(blank=False, null=False)


class Enrolled(models.Model):
    name = models.CharField(max_length=10, null=False, blank=False)
    phone_no = models.IntegerField(max_length=10, blank=False, null=False)
    email = models.CharField(max_length=20, null=False, blank=False)
    amoount_paid = models.FloatField()
    date_enrolled = models.DateField(blank=False, null=False)



