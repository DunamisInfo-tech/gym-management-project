import datetime
import hashlib
from datetime import date

from chartit import DataPool, Chart
from dateutil.relativedelta import relativedelta

from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.urls import reverse
from django.shortcuts import render, render_to_response
from django.template.loader import render_to_string
from django.http import HttpResponse, HttpResponseRedirect
from django.template.loader import get_template
from django.template import Context, Template, RequestContext
import datetime
import hashlib
from random import randint
from django.views.decorators.csrf import csrf_protect, csrf_exempt
from django.template.context_processors import csrf
from .models import expendtitureDetails, Enrolled
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import matplotlib as plt
import json

from app import models
from django.shortcuts import render, render_to_response
from django.template.loader import render_to_string
from django.http import HttpResponse, HttpResponseRedirect
from django.template.loader import get_template
from django.template import Context, Template, RequestContext
import datetime
import hashlib
from random import randint
from django.views.decorators.csrf import csrf_protect, csrf_exempt
from django.template.context_processors import csrf
from .models import payment_stats, datelist, enroll, get1
from django.contrib.auth.models import User, auth
from django.core.mail import send_mail, EmailMultiAlternatives, EmailMessage
from django.db.models import Q
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import redirect
from django.shortcuts import render, render_to_response
from django.template import RequestContext
from django.template.context_processors import csrf
from django.template.loader import render_to_string
from django.views import View
from django.views.decorators.csrf import csrf_protect, csrf_exempt


from app.render import Render
from .models import SalesReport, organization, get, register
from .models import promotion, enquiry1, register

# created in step 4

account_sid = "ACa280b82ed3ceab6943fe9ebd1ee7a984"  # Found on Twilio Console Dashboard
auth_token = "664d1da11e15af4be2ee5fa513956d76"  # Found on Twilio Console Dashboard


# Create your views here.


def index(request):
    items = datelist.objects.all()
    return render(request, 'index.html', {'items': items})



def inde(request):
    return render(request, 'itemhome.html')


def ind(request):
    return render(request, 'in.html')


def index2(request):
    return render(request, 'getstarted.html')


def invitepeople(request):
    return render(request, 'invitepeople.html')


def second(request):
    return render(request, 'second.html')


def basic(request):
    return render(request, 'basic.html')


def email(request):
    return render(request, 'email.html')





def home(request):
    return render(request, 'home.html')


def pageregister(request):
    return render(request, 'page-register.html')


def log(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        print(username)
        user = authenticate(username=username, password=password)
        login(request, user)
        if user:
            return HttpResponseRedirect(reverse('basic'))
        else:
            return HttpResponse('failed')

    return render(request, 'login.html')


def Promotion(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        start_date = request.POST['start_date']
        duration = request.POST['duration']
        end_date = request.POST['end_date']
        user = promotion.objects.create(name=name, email=email, phone=phone, start_date=start_date,
                                        duration=duration,
                                        end_date=end_date)
        user.save()
        print(user)
        return HttpResponse('Registered successfully')
    return render(request, 'promotion.html')


def get3(request):
    if request.method == 'POST':
        email = request.POST['email']
        print(email)
        user1 = get.objects.create(email=email)
        user = authenticate(email=email)
        print(user)
        subject = 'Complete Your Dunamis Signup'
        message = 'hello '
        email_from = 'shekarpooja04@gmail.com'
        recipient_list = [email]
        html_content = render_to_string(
            'verify.html'

        )

        msg = EmailMultiAlternatives(subject, message, email_from, recipient_list)
        msg.attach_alternative(html_content, "text/html")
        msg.send()
        user1.save()
        return render(request, 'second.html')


def inviteemail(request):
    if request.method == 'POST':
        email = request.POST['email']
        emails = []
        for e in email.split(','):
            emails.append(e)
        subject = 'Invitation  to join our Gym'
        message = 'Dear aspirants, To maintain your diet plan and body fitness, do join Gym.'
        email_from = 'nishchithap689@gmail.com'

        email = EmailMessage(subject, message, email_from, emails)
        email.send()

        return render(request, 'second.html')


def link(request):
    send_mail('Subject here', 'Here is the message.', 'nishchithapn9@gmail.com',
              ['nishchithapn9@gmail.com'], fail_silently=False)
    return render(request, 'second.html')


def get2(request):
    if request.method == 'POST':
        email = request.POST['email']
        user = authenticate(email=email)
        print(user)

    return render(request, 'setup.html')


def index1(request):
    dests = promotion.objects.filter(end_date=date.today() + relativedelta(days=3))

    return render(request, 'proindex.html', {'dests': dests})





def enrol(request):
    enroll = User.objects.all()

    return render(request, 'enrollment.html', {'enroll': enroll})


from django.core.exceptions import ValidationError
from django.core.validators import validate_email
import re
from django.contrib import messages


def email1(request):
    dests = promotion.objects.all()
    for j in dests:
        date = j.end_date - datetime.timedelta(days=3)

        if date == date.today():
            print(j.email)

            subject = 'Thank you for registering to our Gym'
            message = ' Hello '
            email_from = 'nishchithap689@gmail.com'
            recipient_list = [j.email]
            send_mail(subject, message, email_from, recipient_list)
            messages.success(request, 'email sent successfully')
    return HttpResponseRedirect(reverse('index1'))


EMAIL_HOST = 'smtp.gmail.com'
EMAIL_USE_TLS = True
EMAIL_PORT = 587
EMAIL_HOST_USER = 'nishchithap689@gmail.com'
EMAIL_HOST_PASSWORD = 'nishchitha@97'


def mobile(request):
    client = TwilioRestClient(account_sid, auth_token)
    message = client.messages.create(
        body="Jenny please?! I love you <3",
        to="+918197349121",
        from_="+919483749579",
        media_url="http://www.example.com/hearts.png")
    print('sent')


def enquiry12(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        plans = request.POST['plans']
        user = enquiry1.objects.create(name=name, email=email, phone=phone, plans=plans)

        messages.info(request, 'Registered successfuly!')
        user.save()
    return render(request, 'details.html')


def is_valid_queryparam(param):
    return param != '' and param is not None


def fil(request):
    qs = enquiry1.objects.all()
    if request.method == 'POST':
        date_min = request.POST['dat_min']
        date_max = request.POST['dat_max']

        if is_valid_queryparam(date_min):
            qs = qs.filter(date__gte=date_min)

        if is_valid_queryparam(date_max):
            qs = qs.filter(date__lte=date_max)

    return render(request, 'enq.html', {'itemt': qs})





def login1(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        print(email)
        user = auth.authenticate(username=User.objects.get(email=username), password=password)
        login(request, user)
        if user:
            return HttpResponseRedirect(reverse('basic'))
        else:
            return HttpResponse('failed')
    return render(request, "page-login.html")


from django.shortcuts import render, redirect

from django.contrib.auth import (
    authenticate,
    get_user_model,
    login,
    logout
)

from .form import UserLoginForm, UserRegisterForm





def register_view(request):
    next = request.GET.get('next')
    form = UserRegisterForm(request.POST or None)
    if form.is_valid():
        user = form.save(commit=False)
        password = form.cleaned_data.get('password')
        user.set_password(password)
        user.save()
        new_user = authenticate(username=user.username, password=password)
        login(request, new_user)
        if next:
            return redirect(next)
        return redirect('datehome')

    context = {
        'form': form,
    }
    return render(request, "signup.html", context)





def enr(request, id):
    items = enroll.objects.get(id=1)
    context = {
        'items': items}
    context['User'] = request.user
    Home(request)
    return render(request, 'pay.html', context)


def enr1(request, id):
    context = {}
    items = enroll.objects.get(id=1)
    context = {
        'items': items}
    context['User'] = request.user

    return render(request, 'paym.html', context)


def pre(request):
    en = enroll.objects.all()
    context = {
        'en1': en
    }

    return render(request, 'pre.html', context)


def business(request):
    en = enroll.objects.all()
    context = {
        'en1': en
    }
    return render(request, 'business.html', context)


class Pdf(View):

    def get(self, request):
        sales = datelist.objects.all()
        params = {
            'items': sales,
            'request': request
        }
        return Render.render('invoice.html', params)


def datehome(request):
    items = datelist.objects.all()
    return render(request, 'itemhome.html', {'items': items})


def add(request):
    if request.method == 'POST':
        iname = request.POST['iname']
        qty = request.POST['qty']
        price = request.POST['price']

        il = datelist.objects.create(product=iname, price=price, qty=qty)
        il.save();
        print('Item inserted')
        return HttpResponseRedirect("datehome")
    else:
        return render(request, 'add.html')


def edit(request, id):
    items = datelist.objects.get(pk=id)
    context = {
        'items': items
    }
    return render(request, 'edit.html', context)


def update(request, id):
    items = datelist.objects.get(pk=id)
    items.name = request.GET['name']
    items.qty = request.GET['qty']

    items.save()
    return redirect('datehome')


def filter(request):
    if request.method == 'POST':
        iname = request.POST['iname']
        if iname:
            i = datelist.objects.filter(Q(product__iexact=iname))

            if i:
                return render(request, 'filter.html', {'itemt': i})


        else:
            return HttpResponseRedirect("filter")

    return render(request, 'filter.html')


def is_valid_queryparam(param):
    return param != '' and param is not None


def searchdate(request):
    qs = datelist.objects.all()
    if request.method == 'POST':
        date_min = request.POST['dat_min']
        date_max = request.POST['dat_max']

        if is_valid_queryparam(date_min):
            qs = qs.filter(date__gte=date_min)

        if is_valid_queryparam(date_max):
            qs = qs.filter(date__lte=date_max)

    return render(request, 'search.html', {'itemt': qs})


def searchmonth(request):
    qs = datelist.objects.all()
    if request.method == 'POST':
        a = request.POST.get('drop')
        b = int(a)
        o = 1
        t = 3
        s = 6
        y = 12

        today = datetime.datetime.now()
        last_month = today.month - 1 if today.month > 1 else 12
        last_tmonth = today.month - 3 if today.month > 1 else 12
        last_smonth = today.month - 6 if today.month > 1 else 12
        last_year = today.year - 1
        last_month_year = today.year if today.month > last_month else today.year - 1

        if b == o:
            q = datelist.objects.filter(date__year=last_month_year, date__month=last_month)
            return render(request, 'search_month.html', {'itemt': q})

        elif b == t:
            q = datelist.objects.filter(date__year=last_month_year, date__month=last_tmonth)
            return render(request, 'search_month.html', {'itemt': q})

        elif b == s:
            q = datelist.objects.filter(date__year=last_month_year, date__month=last_smonth)
            return render(request, 'search_month.html', {'itemt': q})
        elif b == y:
            q = datelist.objects.filter(date__year=last_year)
            return render(request, 'search_month.html', {'itemt': q})

    return render(request, 'search_month.html', {'itemt': qs})


def paymment_data(amountV,firstnameV,emailV,phoneV,productinfoV):
    d={}
    d['amount'] = amountV
    d['firstname'] = firstnameV
    d['email'] = emailV
    d['phone'] = phoneV
    d['productinfo'] = productinfoV
    d['surl'] = 'http://127.0.0.1:8000/Success/'
    d['furl'] = 'http://127.0.0.1:8000/Failure/'
    return d


def Home(request):
    MERCHANT_KEY ="YCElpmvs"
    key ="YCElpmvs"
    SALT ="Ek7BjVCCAY"
    PAYU_BASE_URL ="https://sandboxsecure.payu.in/_payment"
    action = ''
    posted = paymment_data(10, 'koushik', 'koushikravikumargr@gmail.com', 7204994191, 'choclate')
    # posted = {'amount': '10',
    # 		  'firstname': 'renjith',
    # 		  'email': 'sraj@gmail.com',
    # 		  'phone': '9746272610', 'productinfo': 'test',
    # 		  'surl': 'http://127.0.0.1:8000/Success/',
    # 		  'furl': 'http://127.0.0.1:8000/Failure/',
    # 		  'lastname': 'test', 'address1': 'test',
    # 		  'address2': 'test', 'city': 'test',
    # 		  'state': 'test', 'country': 'test',
    # 		  'zipcode': 'tes', 'udf1': '',
    # 		  'udf2': '', 'udf3': '', 'udf4': '', 'udf5': ''
    # 		  }
    # Merchant Key and Salt provided y the PayU.
    for i in request.POST:
        posted[i] = request.POST[i]
    hash_object = hashlib.sha256(b'randint(0,20)')
    txnid = hash_object.hexdigest()[0:20]
    hashh = ''
    posted['txnid'] = txnid
    hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10"
    posted['key'] = key
    hash_string = ''
    hashVarsSeq = hashSequence.split('|')
    for i in hashVarsSeq:
        try:
            hash_string += str(posted[i])
        except Exception:
            hash_string += ''
        hash_string += '|'
    hash_string += SALT
    hashh = hashlib.sha512(hash_string.encode('utf-8')).hexdigest().lower()
    action = PAYU_BASE_URL
    mycontext = {"head": "PayU Money", "MERCHANT_KEY": MERCHANT_KEY, "posted": posted, "hashh": hashh,
                 "hash_string": hash_string, "txnid": txnid, "action": action}

    if (posted.get("key") != None and posted.get("txnid") != None and posted.get("productinfo") != None and posted.get(
            "firstname") != None and posted.get("email") != None):
        return render(request, 'current_datetime.html', context=mycontext)
    else:
        return render_to_response('current_datetime.html', RequestContext(request, {"posted": posted, "hashh": hashh,
                                                                                    "MERCHANT_KEY": MERCHANT_KEY,
                                                                                    "txnid": txnid,
                                                                                    "hash_string": hash_string,
                                                                                    "action": action}))

@csrf_protect
@csrf_exempt
def success(request):
    c = {}
    c.update(csrf(request))
    status = request.POST.get("status")
    firstname = request.POST.get("firstname")
    amount = request.POST.get("amount")
    txnid = request.POST.get("txnid")
    posted_hash = request.POST.get("hash")
    key = request.POST.get("key")
    productinfo = request.POST.get("productinfo")
    email = request.POST.get("email")
    salt = "GQs7yium"
    try:
        additionalCharges = request.POST["additionalCharges"]
        retHashSeq = additionalCharges + '|' + salt + '|' + status + '|||||||||||' + email + '|' + firstname + '|' + productinfo + '|' + amount + '|' + txnid + '|' + key
    except Exception:
        retHashSeq = salt + '|' + status + '|||||||||||' + email + '|' + firstname + '|' + productinfo + '|' + amount + '|' + txnid + '|' + key
    hashh = hashlib.sha512(retHashSeq.encode('utf-8')).hexdigest().lower()
    if (hashh != posted_hash):
        print("Invalid Transaction. Please try again")
    else:
        print("Thank You. Your order status is ", status)
        print("Your Transaction ID for this transaction is ", txnid)
        print("We have received a payment of Rs. ", amount, ". Your order will soon be shipped.")
    context = {"txnid": txnid, "status": status, "amount": amount}
    payment_stats.objects.create(status=status, firstname=firstname, amount=amount, txnid=txnid,
                                 productinfo=productinfo)

    # 	return render_to_response('sucess.html', RequestContext(request,context))
    return render_to_response('sucess.html', context)


@csrf_protect
@csrf_exempt
def failure(request):
    c = {}
    c.update(csrf(request))
    status = request.POST.get("status")
    firstname = request.POST.get("firstname")
    amount = request.POST.get("amount")
    txnid = request.POST.get("txnid")
    posted_hash = request.POST.get("hash")
    key = request.POST.get("key")
    productinfo = request.POST.get("productinfo")
    email = request.POST.get("email")
    salt = "q2plxvdank"
    try:
        additionalCharges = request.POST["additionalCharges"]
        retHashSeq = additionalCharges + '|' + salt + '|' + status + '|||||||||||' + email + '|' + firstname + '|' + productinfo + '|' + amount + '|' + txnid + '|' + key
    except Exception:
        retHashSeq = salt + '|' + status + '|||||||||||' + email + '|' + firstname + '|' + productinfo + '|' + amount + '|' + txnid + '|' + key
    hashh = hashlib.sha512(retHashSeq.encode('utf-8')).hexdigest().lower()
    if (hashh != posted_hash):
        print("Invalid Transaction. Please try again")
    else:
        print("Thank You. Your order status is ", status)
        print("Your Transaction ID for this transaction is ", txnid)
        print("We have received a payment of Rs. ", amount, ". Your order will soon be shipped.")
    return render_to_response("Failure.html", RequestContext(request, c))


def expendtiture(request, daysV=30):
    fdate = datetime.today().date() - timedelta(daysV)
    ldate = datetime.today().date()
    tests = expendtitureDetails.objects.filter(Date__gte=fdate, Date__lte=ldate)
    l = []
    for i in tests:
        l.append(i.price)
    price1 = sum(l)

    tests2 = Enrolled.objects.filter(date_enrolled__gte=fdate, date_enrolled__lte=ldate)
    l2 = []
    for i in tests2:
        l2.append(i.amoount_paid)
    price2 = sum(l2)
    if price2 > price1:
        var = "profit"
        value = price2 - price1
    elif price2 == price1:
        var = "Neutral"
        value = price2
    else:
        var = "loss"
        value = price1 - price2

    x_data = list(i.item for i in tests)
    y_data = list(i.price for i in tests)

    chartdata = {'x': x_data, 'y1': y_data}
    charttype = "pieChart"

    context = {
        'charttype': charttype,
        'chartdata': chartdata,
    }

    return render(request, 'sales.html', {'tests': tests,
                                          'var': var,
                                          'value': value,
                                          'context': context})


def orgnization(request):
    data = organization.objects.only('organizationemail')

    return render(request, "home.html", {'organization': data})
