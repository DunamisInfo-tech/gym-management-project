from django.contrib import admin
from .models import promotion, enquiry1, mail1, organization, get, get1, register, payment_stats, datelist, enroll
# Register your models here.

from .models import SalesReport
from django.contrib import admin
from .models import expendtitureDetails, Enrolled
from datetime import datetime, timedelta


class expendtitureDetailsAdmin(admin.ModelAdmin):
    list_display = ('item', 'quantity', 'Date', 'price')


class enrolledAdmin(admin.ModelAdmin):
    list_display = ('name', 'phone_no', 'email', 'amoount_paid', 'date_enrolled')


admin.site.register(expendtitureDetails, expendtitureDetailsAdmin)
admin.site.register(Enrolled, enrolledAdmin)


class payment_statsAdmin(admin.ModelAdmin):
    list_display = ('status', 'firstname', 'amount', 'txnid', 'productinfo')


from django.contrib import admin
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin



admin.site.register(payment_stats)
admin.site.register(SalesReport)
admin.site.register(promotion)
admin.site.register(get)
admin.site.register(get1)
admin.site.register(organization)
admin.site.register(datelist)
admin.site.register(enquiry1)
admin.site.register(mail1)
admin.site.register(register)
admin.site.register(enroll)
