"""nishu URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from app import views
from app.views import Pdf, Home, failure, success,  register_view
from app.views import expendtiture
urlpatterns = [
    path('admin/', admin.site.urls),
    path('index', views.index, name="index"),
    path('promotion', views.index1, name="index1"),
    path('', views.index2, name="index2"),
    path('home', views.home, name="home"),
    path('pro', views.Promotion),
    path('mobile', views.mobile),
    path("get", views.index1, name="home"),
    path('second', views.second, name="second"),
    path('basic', views.basic, name="basic"),
    path('pre', views.pre, name="pre"),
    path('business', views.business, name="business"),
    path('email', views.email, name="email"),
    path('email1', views.email1, name="email1"),
    path('Payment/', Home),
    path('Success/', success),
    path('Failure/', failure),
    path('render', Pdf.as_view()),
    path('pageregister', views.pageregister),
    path('org', views.orgnization, name='orgnization'),
    path('get3', views.get3, name='get1'),
    path('get2', views.get2, name='get2'),
    path('link', views.link, name='link'),
    path('invitepeople', views.invitepeople, name='link'),
    path('inviteemail', views.inviteemail, name='link'),
    path('log', views.log, name='link'),
    path('enquirydetails', views.enquiry12, name='enquiry'),
    path('login', views.login1, name='login'),
    path('accounts/register/', register_view),
    path('enr', views.enr, name='enr'),
    path('pay/<id>/', views.enr, name='pay'),
    path('paym/<id>/', views.enr1, name='pay'),
    path('enquiry', views.fil, name='fil'),
    path("datehome", views.datehome, name="datehome"),
    path("add", views.add, name="add"),
    path("edit", views.edit, name="edit"),
    path("filter", views.filter, name="filter"),
    path("edit/<id>/", views.edit, name="edit"),
    path("update/<id>/", views.update, name="update"),
    path("render", Pdf.as_view()),
    path("search", views.searchdate, name="search"),
    path("searchmonth", views.searchmonth, name="searchmonth"),
    path("enrollment", views.enrol, name="enrol"),
    path('sales/', expendtiture),


]
